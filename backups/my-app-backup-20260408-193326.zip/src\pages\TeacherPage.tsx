import React from 'react'

const TeacherPage: React.FC = () => {
  return (
    <div style={{ background: '#000', height: '100vh' }}>
      <button>sadsa</button>
    </div>
  )
}

export default TeacherPage
